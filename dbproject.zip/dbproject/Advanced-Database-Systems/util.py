

def isDataReplicated(dataId):
    return dataId % 2 == 0
